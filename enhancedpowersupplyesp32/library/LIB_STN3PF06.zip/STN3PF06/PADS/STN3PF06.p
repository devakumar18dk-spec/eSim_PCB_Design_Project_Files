*PADS-LIBRARY-PART-TYPES-V9*

STN3PF06 SOT230P700X182-4N I ANA 7 1 0 0 0
TIMESTAMP 2026.08.23.06.11.51
"Mouser Part Number" 511-STN3PF06
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STN3PF06?qs=du%252Bo5tJIeNKF3dCiL6LdRg%3D%3D
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STN3PF06
"Description" STN3PF06, P-channel MOSFET Transistor 2.5 A 60 V, 4-Pin SOT-223
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-31/DSA-603442.pdf
"Geometry.Height" 1.82mm
GATE 1 4 0
STN3PF06
1 0 U G
2 0 U D_1
3 0 U S
4 0 U D_2

*END*
*REMARK* SamacSys ECAD Model
5299/2088057/2.50/4/3/Integrated Circuit
